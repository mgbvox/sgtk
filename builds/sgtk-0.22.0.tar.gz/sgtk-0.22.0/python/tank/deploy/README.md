# Backwards compatibility only

**Note!** As of v0.18, `sgtk.deploy` has been split into several other modules.
Some methods and classes been left in order to provide backwards compatibility.
These will be removed at some point in the future.

Do not call any of the methods provided by `sgtk.deploy` - it is not part of the
official `sgtk` API and will be removed at some point.
